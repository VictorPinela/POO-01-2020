package poo06;

public class Agenda {
    private String data;
    private String hora;
    private String medico;
    private String paciente;
    
    public String getData(){
        return this.data;
    }
    public void setData(String p){
        this.data = p;        
    }
    public String getHora(){
        return this.hora;        
    }
    public void setHora(String p){
        this.hora = p;
    }
    public String getMedico(){
        return this.medico;
    }
    public void setMedico(String p){
        this.medico = p;
    }
    public String getPaciente(){
        return this.paciente;
    }
    public void setPaciente(String p){
        this.paciente =  p;    
    }
    
    public Agenda(){
        //construtor padrao
    }
    
    public Agenda(String pData, String pHora,
            String pMedico, String pPaciente){
        try{
            if(pData.isEmpty()){
                throw new Exception("Data nao informada");
            }
            this.data = pData;            
            this.hora = pHora;
            this.medico = pMedico;
            this.paciente = pPaciente;
        }
        catch(Exception err){
           System.out.println("Ocorreu uma exceção – Valores padrões definidos");
           System.out.println(err.getMessage()) ;
        }
    }
    
    
    public void consultar(){
        //todo
    }
    public void mostrar(){
        System.out.println("data="+ data);
        System.out.println("hora="+ hora);
        System.out.println("medico="+ medico);
        System.out.println("paciente="+ paciente);
    }
}
