package poo06;

public class Exame extends Procedimento {
    private String solicitar;
   
    public Exame(String data, String descritivo, String solicitar){
        super(data, descritivo);
        this.solicitar = solicitar;
    }
    
    public String getConsulta(){
        return this.solicitar;
    }
    public void setConsulta(String p){
        this.solicitar = p;
    }
    
    
    public void solicitar(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("EXAME===>");
        System.out.println("consulta="+ getConsulta());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    
}
