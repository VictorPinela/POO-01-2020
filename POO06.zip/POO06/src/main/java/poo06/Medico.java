package poo06;

public class Medico extends Funcionario {
    private long crm;
    private String especialidade;
        

    public Medico(String nome, String telefone, String senha, long crm, String especialidade) {
        super(nome, telefone, senha);
        this.crm = crm;
        this.especialidade = especialidade;
    }
    
    
    public void acessar(){
        //todo
    }
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("crm="+ getCrm());
        System.out.println("telefone="+ getTelefone());
        System.out.println("esp.="+ getEspecialidade());
        System.out.println("senha="+getSenha() );
    }

    
    
    public void realizarConsulta(Consulta obj){
        Receita r1 = new Receita("","","");
        r1.setData("12/03/2020");
        r1.setDescritivo("tylenol");
        obj.getReceitas().add(r1);
        Exame e1 = new Exame("","","");
        e1.setData("12/03/2020");
        e1.setDescritivo("Exame de sangue");
        obj.getExames().add(e1);
        Exame e2 = new Exame("","","");
        e2.setData("12/03/2020");
        e2.setDescritivo("raio x");
        obj.getExames().add(e2);
        obj.mostrar();
    }

    /**
     * @return the crm
     */
    public long getCrm() {
        return crm;
    }

    /**
     * @param crm the crm to set
     */
    public void setCrm(long crm) {
        this.crm = crm;
    }

    /**
     * @return the especialidade
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
}
