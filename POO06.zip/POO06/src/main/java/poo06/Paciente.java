package poo06;

public class Paciente {
    private String nome;
    private String cpf;
    private String telefone;
    private char genero;
    private int idade;
    
    public Paciente(){};
    
    public Paciente(String pNome, 
            String pCpf, String pTelefone, 
            char pGenero, int pIdade){
        try{
            if(pNome.isEmpty()){
                throw new Exception("Nome vazio");
            }
            this.nome = pNome;            
            this.cpf = pCpf;
            this.telefone = pTelefone;
            this.genero = pGenero;
            this.idade = pIdade;
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    //ler o atributo
    public String getNome(){
        return this.nome;
    }
    //gravar atributo
    public void setNome(String p){
        this.nome = p;
    }
    
    public boolean consultar(){        
        return true;
    }
    public void cadastrar(){
    }
    public void mostrar(){
        System.out.println("nome="+getNome());
        System.out.println("cpf="+getCpf());
        System.out.println("telefone="+getTelefone());
        System.out.println("genero="+ getGenero());
        System.out.println("idade="+ getIdade());
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return this.telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the genero
     */
    public char getGenero() {
        return this.genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(char genero) {
        this.genero = genero;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return this.idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

   
   
}