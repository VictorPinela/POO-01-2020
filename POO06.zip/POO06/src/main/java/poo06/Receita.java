package poo06;

public class Receita extends Procedimento {
    private String prescrever;
    
    public Receita(String data, String descritivo, String prescrever){
        super(data, descritivo);
        this.prescrever = prescrever;
    }
    
    
    public void preescrever(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("consulta="+ getPrescrever());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    /**
     * @return the prescrever
     */
    public String getPrescrever() {
        return prescrever;
    }

    /**
     * @param prescrever the prescrever to set
     */
    public void setPrescrever(String prescrever) {
        this.prescrever = prescrever;
    }

    
}
