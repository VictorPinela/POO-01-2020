package poo06;

public class Recepcionista extends Funcionario {
    private String cpf;

    public Recepcionista(String nome, String telefone, String senha, String cpf) {
        super(nome, telefone, senha);
        this.cpf = cpf;
    }
    
    
    
    public void acessar(){ 
        //todo
    }
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("cpf="+ getCpf());
        System.out.println("telefone="+ getTelefone());
        System.out.println("senha="+getSenha() );
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }




    public Paciente fazerFicha(String nome, 
            String cpf, String telefone, 
            char genero, int idade){
        Paciente obj = new Paciente(nome, 
            cpf, telefone, 
            genero, idade);
        if(obj.consultar()==false){
            obj.cadastrar();
        }
        obj.mostrar();
        return obj;
    }
    
    public Consulta marcar(Medico medico, 
            Paciente paciente, Agenda agenda){
        Consulta c1 = new Consulta();
        c1.setAgenda(agenda);
        c1.setMedico(medico);
        c1.setPaciente(paciente);
        c1.marcar();
        return c1;
    }  
/*
    Consulta marcar(Medico ana, Paciente jose, Agenda a1303) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
*/
}