/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo06;

/**
 *
 * @author professor
 */
public class teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Recepcionista maria = new Recepcionista("Jose",
                "123456", "78788-7878", "M");
        Paciente jose = maria.fazerFicha("Jose",
                "123456", "78788-7878", 'M', 40);
        
        Medico ana = new Medico("Ana","123",
                    "4564-4545", 345,"cardio");
        Agenda a1303 = new Agenda("13/03/20",
                "14:00","","");
        Consulta c1 =maria.marcar(ana, jose, a1303);
        ana.realizarConsulta(c1);
    }
    
}
