/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

public class Agenda {
    private String data;
    private String hora;

    
    public String getData(){
        return this.data;
    }
    public void setData(String p){
        this.data = p;        
    }
    public String getHora(){
        return this.hora;        
    }
    public void setHora(String p){
        this.hora = p;
    }
   
    public Agenda(){
        //construtor padrao
    }
    
    public Agenda(String pData, String pHora ){
        try{
            if(pData.isEmpty()){
                throw new Exception("Data nao informada");
            }
            this.data = pData;            
            this.hora = pHora;
  
        }
        catch(Exception err){
           System.out.println("Ocorreu uma exceção – Valores padrões definidos");
           System.out.println(err.getMessage()) ;
        }
    }
    
    
    public void consultar(){
        mostrar();
    }
    
    public void mostrar(){
        System.out.println("data="+ data);
        System.out.println("hora="+ hora);
    }
}
