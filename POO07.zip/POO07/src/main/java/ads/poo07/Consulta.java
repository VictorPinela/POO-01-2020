/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

import java.util.ArrayList;
import java.util.List;

public class Consulta extends Agenda{
    private String data;
    private String hora;
    private Medico medico; //0-N
    private Paciente paciente; //0-N
    private String motivo;
    private String historico; 
    private List<Exame> exames 
            = new ArrayList<Exame>(); //N-N
    private List<Receita> receitas 
            = new ArrayList<Receita>(); //N-N
    private Agenda agenda;
    
    public Consulta(){        
    }
    
    public Consulta(String pData, String pHora,
            Medico pMedico, Paciente pPaciente, 
            String pMotivo, String pHistorico){
        try{
            this.data = pData;
            this.hora = pHora;
            this.medico = pMedico;
            this.paciente = pPaciente;
            this.motivo = pMotivo;
            this.historico = pHistorico;
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    
    public void marcar(){};
    public void cancelar(){};
    public void realizar(){};
    public void atualizar(){};
    @Override
    public void mostrar(){
        System.out.println("data="+ getData());
        System.out.println("hora="+ getHora());
        System.out.println("medico="+ getMedico());
        System.out.println("paciente="+ getPaciente());
        System.out.println("motivo="+ getMotivo());
        System.out.println("historico="+ getHistorico());
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * @return the medico
     */
    public Medico getMedico() {
        return medico;
    }

    /**
     * @param medico the medico to set
     */
    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    /**
     * @return the paciente
     */
    public Paciente getPaciente() {
        return paciente;
    }

    /**
     * @param paciente the paciente to set
     */
    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    /**
     * @return the motivo
     */
    public String getMotivo() {
        return motivo;
    }

    /**
     * @param motivo the motivo to set
     */
    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    /**
     * @return the historico
     */
    public String getHistorico() {
        return historico;
    }

    /**
     * @param historico the historico to set
     */
    public void setHistorico(String historico) {
        this.historico = historico;
    }

    /**
     * @return the exames
     */
    public List<Exame> getExames() {
        return exames;
    }

    /**
     * @param exames the exames to set
     */
    public void setExames(List<Exame> exames) {
        this.exames = exames;
    }

    /**
     * @return the receitas
     */
    public List<Receita> getReceitas() {
        return receitas;
    }

    /**
     * @param receitas the receitas to set
     */
    public void setReceitas(List<Receita> receitas) {
        this.receitas = receitas;
    }

    /**
     * @return the agenda
     */
    public Agenda getAgenda() {
        return agenda;
    }

    /**
     * @param agenda the agenda to set
     */
    public void setAgenda(Agenda agenda) {
        this.agenda = agenda;
    }
    
    @Override
    public void consultar(){
        mostrar();
    }
}
