/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

public class Medico extends Funcionario{
    private long crm;
     private String especialidade;
    
    public Medico(){        
    }
    public Medico(String pNome, long pCrm, 
            String pTelefone, String pEspecialidade)
    {
       try{
        setNome(pNome);
        setCrm(pCrm);
        setTelefone(pTelefone);
        setEspecialidade(pEspecialidade);
       }
       catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }       
    
    
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("crm="+ getCrm());
        System.out.println("telefone="+ getTelefone());
        System.out.println("esp.="+ getEspecialidade());
        System.out.println("senha="+getSenha() );
    }

    
    /**
     * @return the crm
     */
    public long getCrm() {
        return crm;
    }

    /**
     * @param crm the crm to set
     */
    public void setCrm(long crm) {
        this.crm = crm;
    }

  
    /**
     * @return the especialidade
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    
    public void realizarConsulta(Consulta obj){
        Receita r1 = new Receita();
        r1.setData("12/03/2020");
        r1.setDescritivo("tylenol");
        obj.getReceitas().add(r1);
        Exame e1 = new Exame();
        e1.setData("12/03/2020");
        e1.setDescritivo("Exame de sangue");
        obj.getExames().add(e1);
        Exame e2 = new Exame();
        e2.setData("12/03/2020");
        e2.setDescritivo("raio x");
        obj.getExames().add(e2);
        obj.mostrar();
    }
    
    @Override
    public boolean acessar(){
        System.out.println("Medico liberado");
        return true;
    }
}
