/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

public abstract class Procedimento {
    String data;
    String descritivo;

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the descritivo
     */
    public String getDescritivo() {
        return descritivo;
    }

    /**
     * @param descritivo the descritivo to set
     */
    public void setDescritivo(String descritivo) {
        this.descritivo = descritivo;
    }
    
    public void cosultar(){
        System.out.println("Procedimento\n==========================");
        System.out.println("Data="+ this.data);
        System.out.println("Descritivo="+ this.descritivo);
    }
    
}