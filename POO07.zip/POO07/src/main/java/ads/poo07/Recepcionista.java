/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

public class Recepcionista extends Funcionario { 
    private String cpf;

    public Recepcionista(){}
    
    public Recepcionista(String pNome, 
            String pCpf, String pTelefone){
        try{
            setNome(pNome);
            setCpf(pCpf);
            setTelefone(pTelefone);
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("cpf="+ getCpf());
        System.out.println("telefone="+ getTelefone());
        System.out.println("senha="+getSenha() );
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    
    
    public Paciente fazerFicha(String nome, 
            String cpf, String telefone, 
            char genero, int idade){
        Paciente obj = new Paciente(nome, 
            cpf, telefone, 
            genero, idade);
        if(obj.consultar()==false){
            obj.cadastrar();
        }
        obj.mostrar();
        return obj;
    }
    
    public Consulta marcar(Medico medico, 
            Paciente paciente, Agenda agenda){
        Consulta c1 = new Consulta();
        c1.setAgenda(agenda);
        c1.setMedico(medico);
        c1.setPaciente(paciente);
        c1.marcar();
        return c1;
    }
    
    @Override
    public boolean acessar(){
        System.out.println("Recepcionista liberado");
        return true;
    }
    
}
