/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_1;

/**
 *
 * @author adm
 */
public interface CalculoArea {
    public float area();
}
