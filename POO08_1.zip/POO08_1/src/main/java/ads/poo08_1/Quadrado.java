/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_1;

/**
 *
 * @author adm
 */
public class Quadrado implements CalculoArea {
    
    private float lado;
    
    public Quadrado(float lado){
        this.lado = lado;
    };
    
    @Override
    public float area() {
        float area = this.lado * this.lado;
        return area;
        }

    /**
     * @return the lado
     */
    public float getLado() {
        return lado;
    }

    /**
     * @param lado the lado to set
     */
    public void setLado(float lado) {
        this.lado = lado;
    }

        
}
