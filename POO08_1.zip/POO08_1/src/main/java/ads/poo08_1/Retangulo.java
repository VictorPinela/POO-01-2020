/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_1;

/**
 *
 * @author adm
 */
public class Retangulo implements CalculoArea {
    
    private float base;
    private float altura;
    
    public Retangulo(float base, float altura){
        this.base = base;
        this.altura = altura;
    };
    
    @Override
    public float area() {
        float area = this.base * this.altura;
        return area;
        }

    /**
     * @return the base
     */
    public float getBase() {
        return base;
    }

    /**
     * @param base the base to set
     */
    public void setBase(float base) {
        this.base = base;
    }

    /**
     * @return the altura
     */
    public float getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(float altura) {
        this.altura = altura;
    }
    
}
