/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_1;

/**
 *
 * @author adm
 */
public class Teste {

    
    public static void main(String[] args) {
        Quadrado q1 = new Quadrado(2);
        q1.area();
        Retangulo r1 = new Retangulo(2, 4);
        r1.area();
        Triangulo t1 = new Triangulo(3, 6);
        t1.area();
        System.out.println(q1.area());
        System.out.println(r1.area());
        System.out.println(t1.area());
    }
    
}
