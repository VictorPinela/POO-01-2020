/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_2;

/**
 *
 * @author adm
 */
public interface Colaborador {
    
    public static float valorHora = 0; 
	
	public float obtemSalario();
	
	public float getCargaHoraria();
    
}
