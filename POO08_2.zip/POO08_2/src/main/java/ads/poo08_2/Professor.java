/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_2;

/**
 *
 * @author adm
 */

public interface Professor {
	
	public double GRADUACAO = 1;
	public double MESTRADO = 1.2;
	public double DOUTORADO = 1.5;
	
	public String obtemTitulacao(float cargaHoraria, String graduacao);

}
