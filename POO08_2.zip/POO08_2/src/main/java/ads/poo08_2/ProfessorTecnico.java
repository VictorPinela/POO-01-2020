/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo08_2;

/**
 *
 * @author adm
 */
public class ProfessorTecnico implements Professor, Colaborador{

    @Override
    public String obtemTitulacao(float cargaHoraria, String graduacao) {
        return "GRADUACAO";
    }

    private float valorBase = 30;
   

	private float cargaHoraria = 176;
	
	@Override
	public float getCargaHoraria() {
		return cargaHoraria;
	}

	public void setCargaHoraria(float cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}

	@Override
	public float obtemSalario() {
		double salario = (cargaHoraria * valorHora) * 3 * this.GRADUACAO;
		return (float) salario;
	}
    
}
